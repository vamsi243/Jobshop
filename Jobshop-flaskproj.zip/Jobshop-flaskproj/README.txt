I used some additional files in this program and due to memory constraints i have attached all the addional files in the below onedrive link.
Onedrive link: https://rmiteduau-my.sharepoint.com/:u:/g/personal/s3884753_student_rmit_edu_au/EatTOsnKT1tIgxfrOH3o_osBxy3OLlQws-wqhZtO81djhg?e=GRzdjs

Features:

The home page contains the preview of top jobs listed on the website.
Searching the keywords on the search filed displays top 4 jobs from the all the jobs.
Job category is a hover-type dropdown menu that displays different job categories.
Selecting the a job category from dropdown directs to that particular job category page.
After clicking on admin and entering the log in details:
username: Sai (Note: Capital 'S')
password: TestingRMIT
An Admin can enter the job title and job description
After entering the details, click on classify. Based on job description it classifies job to a category.
Also, admin can edit the classification category if the generated classification does not meet the requirements.
