
# Code to import libraries as you need in this assessment, e.g.,  
import numpy as np
from nltk import RegexpTokenizer
from nltk.tokenize import sent_tokenize
from itertools import chain
from nltk.probability import *


#This function converts the description into tokens
def tokenizeDescription(discip):
    """
        This function first convert all words to lowercases, 
        it then segment the raw review into sentences and tokenize each sentences 
        and convert the review to a list of tokens.
    """     
    # convert all words to lowercase   
    #nl_discip = [word.lower() for word in discip]
    nl_discip = discip.lower() 

    
    # segament into sentences
    sentences = sent_tokenize(nl_discip)
    
    # tokenize each sentence
    pattern =  r"[a-zA-Z]+(?:[-'][a-zA-Z]+)?"
    tokenizer = RegexpTokenizer(pattern) 
    token_lists = [tokenizer.tokenize(sen) for sen in sentences]
    
    # merge them into a list of tokens
    tokenised_descrip = list(chain.from_iterable(token_lists))
    return tokenised_descrip