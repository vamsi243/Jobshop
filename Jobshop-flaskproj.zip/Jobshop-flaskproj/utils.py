import pandas as pd
import numpy as np
def gen_docVecs(wv,tk_txts): # generate vector representation for documents
    docs_vectors =[] # creating empty final list
    for i in range(0,len(tk_txts)):
            tokens = tk_txts[i]
            temp = []  # creating a temporary list(store value for 1st doc & for 2nd doc remove the details of 1st & proced through 2nd and so on..)
            temp2=[]   #It holds the temp values after each iteration
            for w_ind in range(0, len(tokens)): # looping through each word of a single document and spliting through space
                try:
                    word = tokens[w_ind]
                    word_vec = wv[word] # if word is present in embeddings(google provides weights associate with words(300)/fasttext with size 200) then proceed
                    temp = pd.Series(word_vec) # if word is present then assign it to temp.
                    temp2.append(temp)
                except:
                    pass
                temp=[]
            zk=np.sum(np.array(temp2),axis=0) #The sum is calculated and stored in zk, a temp variable
            docs_vectors.append(zk) #toring all the doc vectors in this list.
    return docs_vectors


