import os
import pickle
from bs4 import BeautifulSoup
from flask import Flask, render_template, request, redirect, session
from gensim.models.fasttext import FastText
from utils import gen_docVecs
from itertools import chain
from util1 import tokenizeDescription
from nltk.tokenize import sent_tokenize
from itertools import chain
from nltk.probability import *
from nltk.util import ngrams
from nltk.stem import LancasterStemmer

app = Flask(__name__)
app.secret_key = os.urandom(16) 

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/Accounting_Finance')
def Accounting_Finance():
    return render_template('Accounting_Finance.html')

@app.route('/Engineering')
def Engineering():
    return render_template('Engineering.html')

@app.route('/Healthcare_Nursing')
def Healthcare_Nursing():
    return render_template('Healthcare_Nursing.html')

@app.route('/Hospitality_Catering')
def Hospitality_Catering():
    return render_template('Hospitality_Catering.html')

@app.route('/IT')
def EngineerITing():
    return render_template('IT.html')

@app.route('/PR_Advertising_Marketing')
def PR_Advertising_Marketing():
    return render_template('PR_Advertising_Marketing.html')

@app.route('/Sales')
def Sales():
    return render_template('Sales.html')

@app.route('/Teaching')
def Teaching():
    return render_template('Teaching.html')

@app.route('/about')
def about():
    return render_template('about.html')



@app.route('/<folder>/<filename>')
def article(folder, filename): #job_template
    return render_template('/' + folder + '/' + filename + '.html')

@app.route("/admin", methods=['GET', 'POST']) 
def admin():
    if 'username' in session:
        if request.method == 'POST':

            # Read the .txt file
            f_title = request.form['title']
            f_desc = request.form['description']

            # Classify the content
            if request.form['button'] == 'Classify':

                # Tokenize the content of the .txt file so as to input to the saved model - can do more complicated things here but as an example in the exercise, we just stop here
                #tokenizing description based on the regextokenizer
                tk_desc = tokenizeDescription(f_desc)
                # removing words which are less than 2 in job description
                tk_descrip1 = [w for w in tk_desc if len(w) >=2]
                #removing stopwords on the data based on stopwords_en.txt from job description ,title and title+description statistics
                #storing the stop words in a list structure.
                stopwords_en = []
                with open('./stopwords_en.txt') as f:
                    stopwords_en = f.read().splitlines()
                
                # flitering stop words from job description
                tokenized_data = [token for token in tk_descrip1 if token not in stopwords_en] #Check the existance of words against the stopwords and extract them in list comprehension

                # Load the FastText model
                jobDescFT = FastText.load("jobDescFT.model")
                jobDescFT_wv= jobDescFT.wv
            
                # Generate vector representation of the tokenized data
                jobDescFT_dvs = gen_docVecs(jobDescFT_wv, [tokenized_data])

                # Load the LR model
                pkl_filename = "jobDescFT.pkl"
                with open(pkl_filename, 'rb') as file:
                    model = pickle.load(file)

                # Predict the label of tokenized_data
                y_pred = model.predict(jobDescFT_dvs)
                y_pred = y_pred[0]

                return render_template('admin.html', prediction=y_pred, title=f_title, description=f_desc)

            elif request.form['button'] == 'Save':

                # First check if the recommended category is empty
                cat_recommend = request.form['category']
                if cat_recommend == '':
                    return render_template('admin.html', prediction=cat_recommend,
                                        title=f_title, description=f_desc,
                                        category_flag='Recommended category must not be empty.')

                elif cat_recommend not in ['Accounting_Finance','Sales','Teaching','IT', 'Engineering', 'Healthcare_Nursing', 'Hospitality_Catering', 'PR_Advertising_Marketing']:
                    return render_template('admin.html', prediction=cat_recommend,
                                        title=f_title, description=f_desc,
                                        category_flag='Recommended category must belong to: Accounting_Finance,Sales,Teaching,IT,Engineering, Healthcare_Nursing,Hospitality_Catering,PR_Advertising_Marketing')

                else:

                    # First read the html template
                    soup = BeautifulSoup(open('templates/job_template.html'), 'html.parser')
                    
                    # Then adding the title and the content to the template
                    # First, add the job title
                    div_page_title = soup.find('div', { 'class' : 'title' })
                    title = soup.new_tag('h1', id='job-title')
                    title.append(f_title)
                    div_page_title.append(title)

                    # Second, add the job description
                    div_page_desc = soup.find('div', { 'class' : 'description' })
                    desc = soup.new_tag('p',id="job-description")
                    desc.append(f_desc)
                    div_page_desc.append(desc)

                    # Finally write to a new html file
                    filename_list = f_title.split()
                    filename = '_'.join(filename_list)
                    filename =  cat_recommend + '/' + filename + ".html"
                    with open("templates/" + filename, "w", encoding='utf-8') as file:
                        print(filename)
                        file.write(str(soup))

                    # Clear the add-new-entry form and ask if user wants to continue to add new entry
                    return redirect('/' + filename.replace('.html', ''))

        else:
            return render_template('admin.html')
    else:
        return redirect('/login')


@app.route('/login', methods = ['GET', 'POST'])
def login():
    if request.method == 'POST':
        if (request.form['username'] == 'Sai') and (request.form['password'] == 'TestingRMIT'):
            session['username'] = request.form['username']
            return redirect('/admin')
        else:
            return render_template('login.html', login_message='Username or password is invalid.')
    
    return render_template('login.html')


@app.route('/logout')
def logout():
    # remove the username from the session if it is there
    session.pop('username', None)

    return redirect('/')


@app.route('/search', methods = ['POST'])
def search():

    if request.method == 'POST':
    
        if request.form['search'] == '':
            search_string = request.form["searchword"]
            #Used a lancaster stemmer, to stem the search string.
            lancaster=LancasterStemmer()
            search_string= lancaster.stem(search_string)
            # search over all the html files in templates to find the search_string
            job_search = []
            dir_path = 'templates'
            for folder in os.listdir(dir_path):
                if os.path.isdir(os.path.join(dir_path, folder)):
                    for filename in sorted(os.listdir(os.path.join(dir_path, folder))):
                        if filename.endswith('html'):
                            with open(os.path.join(dir_path, folder, filename), encoding="utf8") as file:
                                file_content = file.read()

                                # search for the string within the file
                                if search_string in file_content:
                                    job_search.append([folder, filename.replace('.html', '')])
            
            # generate the right format for the Jquery script in search.html
            num_results = len(job_search)

            # exact search or related search (regex, stemming or lemmatizing)

            # can handle the case when no search results

            # search both titles and descriptions

            return render_template('search.html', num_results=num_results, search_string=search_string,
                                   job_search=job_search)
    
    else:
        return render_template('home.html')


